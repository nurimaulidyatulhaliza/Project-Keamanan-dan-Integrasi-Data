import requests
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives import hashes, serialization
import binascii
import os

# Konfigurasi URL sesuai api.py
URL = "http://localhost:8080"

def run_simulation():
    print("=== Simulasi Lab Vegapunk: Punk Records v1 ===")

    # 1. Login (Mendapatkan Token - Secure Session)
    print("\n[1] Melakukan Login...")
    login_payload = {"username": "foreman", "password": "foreman123"}
    res_login = requests.post(f"{URL}/login", data=login_payload)
    
    if res_login.status_code != 200:
        print("Login Gagal! Pastikan api.py sudah jalan di terminal lain.")
        return

    token = res_login.json().get("access_token")
    headers = {"Authorization": f"Bearer {token}"}
    print(f"Login Berhasil! Token JWT: {token[:20]}...")

    # 2. Membuat Kunci SECP256K1 (Variasi Cipher - Asymmetric)
    print("\n[2] Membuat Pasangan Kunci Asimetris (EC SECP256K1)...")
    priv_key = ec.generate_private_key(ec.SECP256K1())
    pub_key_bytes = priv_key.public_key().public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo
    )
    
    # Simpan ke file lokal
    with open("my_pub.pem", "wb") as f: 
        f.write(pub_key_bytes)
    print("Public Key berhasil dibuat dan disimpan di 'my_pub.pem'")

    # 3. Store Public Key ke Server (Multiuser & Integrity)
    print("\n[3] Mengunggah Public Key ke Server...")
    with open("my_pub.pem", "rb") as f:
        res_store = requests.post(
            f"{URL}/store", 
            data={'user_id': 'foreman'}, 
            files={'pubkey_file': f}, 
            headers=headers
        )
    print(f"Response Server: {res_store.json()}")

    # 4. Verify Signature (Integrity Check)
    print("\n[4] Menguji Verifikasi Signature Digital...")
    msg = "Data Rahasia Egghead"
    # Menandatangani pesan dengan private key
    sig = priv_key.sign(msg.encode(), ec.ECDSA(hashes.SHA256()))
    signature_hex = binascii.hexlify(sig).decode()
    print(f"Signature (Hex): {signature_hex[:30]}...")
    
    # Kirim ke server untuk diverifikasi menggunakan public key yang tadi disimpan
    v_res = requests.post(f"{URL}/verify", json={
        "user_id": "foreman",
        "message": msg,
        "signature": signature_hex
    }, headers=headers)
    print(f"Hasil Verifikasi Server: {v_res.json()}")

    # 5. Relay Message (Multiuser - Mengirim ke User Lain)
    print("\n[5] Simulasi Relay Pesan ke Peneliti Lain (Kevin)...")
    # Sesuai RelayRequest di api.py: recipient_id & encrypted_message
    relay_payload = {
        "recipient_id": "kevin",
        "encrypted_message": "AES_ENCRYPTED_DATA_FOR_KEVIN"
    }
    res_relay = requests.post(f"{URL}/relay", json=relay_payload, headers=headers)
    print(f"Hasil Relay: {res_relay.json()}")

    # 6. Integrity Check PDF
    print("\n[6] Upload PDF & Cek Hash SHA-256...")
    # Membuat file dummy PDF jika belum ada
    with open("report.pdf", "w") as f: 
        f.write("Laporan Rahasia Proyek Stella")
    
    with open("report.pdf", "rb") as f:
        res_pdf = requests.post(
            f"{URL}/upload-pdf", 
            files={'file': f}, 
            headers=headers
        )
    print(f"SHA256 dari Server: {res_pdf.json().get('sha256')}")
    print(f"Status: {res_pdf.json().get('status')}")

    # 7. Health Check
    print("\n[7] Mengecek Health System...")
    res_health = requests.get(f"{URL}/health")
    health_data = res_health.json()
    print(f"System Version: {health_data['version']}")
    print(f"Active Features: {list(health_data['features'].keys())}")

if __name__ == "__main__":
    run_simulation()
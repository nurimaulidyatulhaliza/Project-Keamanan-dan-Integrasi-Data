from fastapi import FastAPI, HTTPException, UploadFile, File, Form, Depends
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional
from datetime import datetime, timedelta
from jose import jwt, JWTError
import os
import json
import binascii
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.backends import default_backend

app = FastAPI(title="Punk Records v1", version="1.0.0")

# KONFIGURASI KEAMANAN (Secure Session)
SECRET_KEY = "RAHASIA_NEGARA_STELLA_A"
ALGORITHM = "HS256"
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="login")

# Simulasi Database User Terdaftar di Egghead
MOCK_USERS = {
    "foreman": {"username": "foreman", "password": "foreman123"},
    "kevin": {"username": "kevin", "password": "kevin123"}
}

USER_DATA_FILE = "user_public_keys.json"

def load_keys():
    if os.path.exists(USER_DATA_FILE):
        with open(USER_DATA_FILE, "r") as f:
            return json.load(f)
    return {}

def save_keys(data):
    with open(USER_DATA_FILE, "w") as f:
        json.dump(data, f, indent=4)

USER_PUBLIC_KEYS = load_keys()

# --- FUNGSI JWT (Grade A) ---
def create_access_token(data: dict):
    to_encode = data.copy()
    expire = datetime.utcnow() + timedelta(minutes=30)
    to_encode.update({"exp": expire})
    return jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)

async def get_current_user(token: str = Depends(oauth2_scheme)):
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        username = payload.get("sub")
        if username is None or username not in MOCK_USERS:
            raise HTTPException(status_code=401, detail="Invalid Session")
        return username
    except JWTError:
        raise HTTPException(status_code=401, detail="Session Expired")

# --- ENDPOINTS ---

class VerifyRequest(BaseModel):
    user_id: str
    message: str
    signature: str

class RelayRequest(BaseModel):
    recipient_id: str
    encrypted_message: str

@app.post("/login")
async def login(form_data: OAuth2PasswordRequestForm = Depends()):
    user = MOCK_USERS.get(form_data.username)
    if not user or form_data.password != user["password"]:
        raise HTTPException(status_code=400, detail="Wrong credentials")
    
    access_token = create_access_token(data={"sub": user["username"]})
    return {"access_token": access_token, "token_type": "bearer"}

# TODO:
# Lengkapi fungsi berikut untuk menerima unggahan, memeriksa keutuhan file, lalu
# menyimpan public key milik user siapa
# Tentukan parameters fungsi yang diperlukan untuk kebutuhan ini
@app.post("/store")
async def store_pubkey(
    user_id: str = Form(...), 
    pubkey_file: UploadFile = File(...),
    current_user: str = Depends(get_current_user)
):
    content = await pubkey_file.read()
    try:
        # Integrity Check: Memastikan file adalah Public Key valid
        serialization.load_pem_public_key(content, backend=default_backend())
        
        USER_PUBLIC_KEYS[user_id] = content.decode('utf-8')
        save_keys(USER_PUBLIC_KEYS)
        return {"message": f"Public key for {user_id} securely saved by {current_user}"}
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid Public Key Format")

# Fungsi API untuk memverifikasi signature yang dibuat oleh seorang pengguna
# TODO:
# Lengkapi fungsi berikut untuk menerima signature, menghitung signature dari "tampered message"
# Lalu kembalikan hasil perhitungan signature ke requester
# Tentukan sendiri parameters fungsi yang diperlukan untuk kebutuhan ini
@app.post("/verify")
async def verify(request: VerifyRequest, current_user: str = Depends(get_current_user)):
    try:
        pub_key_pem = USER_PUBLIC_KEYS.get(request.user_id)
        if not pub_key_pem:
            raise HTTPException(status_code=404, detail="Public key not found")

        public_key = serialization.load_pem_public_key(
            pub_key_pem.encode(), 
            backend=default_backend()
        )
        
        signature = binascii.unhexlify(request.signature)
        
        # Proses Verifikasi
        public_key.verify(
            signature,
            request.message.encode(),
            ec.ECDSA(hashes.SHA256())
        )
        return {"is_valid": True, "status": "Integrity Verified", "signer": request.user_id}
    except Exception as e:
        # Jika signature tidak cocok, akan masuk ke sini
        return {"is_valid": False, "error": "Signature Mismatch / Tampered Data"}

# Fungsi API untuk relay pesan ke user lain yang terdaftar
# TODO:
# Lengkapi fungsi berikut untuk menerima pesan yang aman ke server, 
# untuk selanjutnya diteruskan ke penerima yang dituju (ditentukan oleh pengirim)
# Tentukan sendiri parameters fungsi yang diperlukan untuk kebutuhan ini
@app.post("/relay")
async def relay(request: RelayRequest, current_user: str = Depends(get_current_user)):
    recipient_id = request.recipient_id
    if recipient_id not in MOCK_USERS:
        raise HTTPException(status_code=404, detail="Recipient not found")

    return {
        "status": "Relayed Successfully",
        "from": current_user,
        "to": recipient_id,
        "secure_payload": request.encrypted_message
    }

# Akses API pada URL http://localhost:8080/upload-pdf
@app.post("/upload-pdf")
async def upload_pdf(file: UploadFile = File(...), current_user: str = Depends(get_current_user)):
    # Integrity Check: Hashing file yang diunggah
    contents = await file.read()
    sha256_hash = hashes.Hash(hashes.SHA256(), backend=default_backend())
    sha256_hash.update(contents)
    digest = binascii.hexlify(sha256_hash.finalize()).decode()

    return {
        "filename": file.filename,
        "sha256": digest,
        "uploaded_by": current_user,
        "status": "Integrity Verified"
    }

# Fungsi akses pada lokasi "root" atau "index"
@app.get("/health", tags=["System"])
async def health():

    return {
        "status": "Healthy",
        "timestamp": datetime.now().isoformat(),
        "version": "1.0.0-Stella-Grade",
        "features": {
            "secure_session": "Active (JWT)",
            "multiuser": "Enabled",
            "integrity_check": "SHA-256"
        }
    }